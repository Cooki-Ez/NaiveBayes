public class Classifier {

    //if true = p, if false = e
    public boolean specified;
    public boolean correct;

    Classifier(boolean s, boolean c) {
        specified = s;
        correct = c;
    }
}
